
Vue.component('vue-gallery', {
    props: ['photos'],
    data: function () {
      return {
        activePhoto: null
      }
    },
    template: `
      <div class="vueGallery">
      <div class="activePhoto" :style="'background-image: url('+photos[activePhoto]+');'">
        <button type="button" aria-label="Previous Photo" class="previous" @click="previousPhoto()">
          <i class="fas fa-chevron-circle-left"></i>
        </button>
        <button type="button" aria-label="Next Photo" class="next" @click="nextPhoto()">
          <i class="fas fa-chevron-circle-right"></i>
        </button>
      </div>
      <div class="thumbnails">
        <div
             v-for="(photo, index) in photos"
             :src="photo"
             :key="index"
             @click="changePhoto(index)"
             :class="{'active': activePhoto == index}" :style="'background-image: url('+photo+')'">
        </div>
      </div>
    </div>`,
    mounted () {
      this.changePhoto(0)
      document.addEventListener("keydown", (event) => {
        if (event.which == 37)
          this.previousPhoto()
        if (event.which == 39)
          this.nextPhoto()
      })
    },
    methods: {
      changePhoto (index) {
        this.activePhoto = index
      },
      nextPhoto () {
        this.changePhoto( this.activePhoto+1 < this.photos.length ? this.activePhoto+1 : 0 )
      },
      previousPhoto () {
        this.changePhoto( this.activePhoto-1 >= 0 ? this.activePhoto-1 : this.photos.length-1 )
      }
    }
  })
  
  new Vue({
    el: '#app',
    data: {
      photos: [
        'img/暗夜使者.jpg' ,
        'img/缔造者.jpg',
        'img\黑暗武士.jpg',
        'img\魔枪士.jpg',
        'img\男魔法师.jpg',
        'img\女格斗家.jpg',
        'img\女鬼剑士.jpg',
        'img\女魔法师.jpg'
      ]
    }
  });